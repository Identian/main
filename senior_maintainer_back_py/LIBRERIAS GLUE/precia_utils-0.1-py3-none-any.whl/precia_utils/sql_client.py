from precia_utils.precia_logs import setup_logging
import sqlalchemy
import json
import pymysql
pymysql.install_as_MySQLdb()
import boto3

logger = setup_logging()
secretsmanagerClient = boto3.client('secretsmanager')


def getSecret(secretName):
    try:
        get_secret_value_response = secretsmanagerClient.get_secret_value(SecretId=secretName)
        secret = get_secret_value_response['SecretString']
        parameters = json.loads(secret)
    except (Exception,) as sec_exc:
        error_msg = "No se pudo obtener el secreto"
        logger.error(error_msg)
        raise Exception
    return parameters


def create_connection_pool(db_secret):
    try:
        connect_db_url = (db_secret)
        sql_engine = sqlalchemy.create_engine(connect_db_url, pool_size=38, # cantidad de conexiones
        max_overflow=2, # cantidad extras de conexiones sobre las reservadas            
        echo_pool="debug",
        echo=True,
        pool_pre_ping=True,)
        return sql_engine
    except sqlalchemy.exc.SQLAlchemyError as sql_e:
        logger.error("No se pudo crear un engine para la base de datos")
        logger.error(sql_e)
        raise Exception("Fallo la conexion a la base de datos.") from sql_e


