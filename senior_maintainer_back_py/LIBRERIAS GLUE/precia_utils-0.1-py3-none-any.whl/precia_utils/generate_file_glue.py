import datetime
import sys
import pandas as pd
import boto3
import json
from awsglue.utils import getResolvedOptions 
from precia_utils.precia_logs import setup_logging, create_log_msg
from precia_utils.sql_client import create_connection_pool
from precia_utils.error import NoRecords, ErrorFile

logger = setup_logging()
secretsmanagerClient = boto3.client('secretsmanager')

def get_enviroment_variable(variable):
    variable_value = getResolvedOptions(sys.argv, [variable])
    return variable_value[variable] 

def getSecret(secretName):
    try:
        get_secret_value_response = secretsmanagerClient.get_secret_value(SecretId=secretName)
        secret = get_secret_value_response['SecretString']
        parameters = json.loads(secret)
    except (Exception,) as sec_exc:
        error_msg = "No se pudo obtener el secreto"
        logger.error(create_log_msg(error_msg))
    return parameters



class FileGenerator:
    def __init__(self) -> None:
        #self.flash2_string_connection = "mysql+pymysql://root:root@localhost:3306/precia_published"
        #self.file_format_string_connection = "mysql+pymysql://root:root@localhost:3306/file_generator"
        self.flash2_string_connection = "mysql+pymysql://dvanegas:ROJIn4J2@rds-dev-back-8.cwejzmqeyiuq.us-east-1.rds.amazonaws.com:3306/precia_published"
        self.file_format_string_connection = "mysql+pymysql://dvanegas:ROJIn4J2@rds-dev-back-8.cwejzmqeyiuq.us-east-1.rds.amazonaws.com:3306/precia_published"
        self.valuation_date = get_enviroment_variable('VALUATION_DATE')
        self.entry_file_id = get_enviroment_variable('FILE_ID')

    def run(self) -> None:
        valuation_date = datetime.datetime.strptime(self.valuation_date, '%Y-%m-%d')
        file_info = self.execute_query(self.file_format_string_connection, "SELECT id, prefix, query FROM rfl_files WHERE prefix ='{}'".format(self.entry_file_id))
        if file_info.empty:
            raise NoRecords(error_message='La consulta a la tabla que contiene el query no retorno resultado')
        header_info = self.execute_query(self.file_format_string_connection,"SELECT id, file_id, field_index, value_type, default_value, column_reference, pattern FROM rfl_file_header WHERE file_id = '{}'".format(file_info.loc[0]['id']))
        if header_info.empty:
            raise NoRecords(error_message='La consulta a la tabla que contiene el header del archivo no retorno resultado')
        column_info = self.execute_query(self.file_format_string_connection,"SELECT id, file_id, field_index, column_name, value_type, is_incremental, default_value, pattern FROM rfl_file_column WHERE file_id = '{}'".format(file_info.loc[0]['id']))
        if column_info.empty:
            raise NoRecords(error_message='La consulta a la tabla que contiene el formato de columnas del archivo no retorno resultado')
        query = file_info.loc[0]['query'].format(valuation_date.strftime('%Y-%m-%d'))
        data = self.execute_query(self.flash2_string_connection, query)
        if data.empty:
            raise NoRecords(error_message='La consulta a la tabla que contiene los datos para el archivo no retorno resultado')

        file_name = self.build_file_name(self.entry_file_id, valuation_date)
        header_field_list = self.build_header(file_name, header_info, data, valuation_date)
        data_row_list = self.build_data(column_info, data)
        self.build_file(file_name, header_field_list, data_row_list)

    
    def build_file(self, file_name: str, header_list: list, data_list: list) -> None:
        logger.info("Construyendo archivo final")
        try:
            header_string, data_list_string, file_content = "","",""
            for header_field in header_list:
                header_string+=header_field
            header_string+="\n"
            for data_row in data_list:
                data_list_string+=data_row
            file_content += header_string+data_list_string
            bucket_name = get_enviroment_variable("S3_BUCKET")
            s3_path = get_enviroment_variable("S3_PATH") + file_name
            s3 = boto3.resource("s3")
            logger.info("Guardando el archivo en s3")
            s3.Bucket(bucket_name).put_object(Key=s3_path, Body=file_content)
        except Exception as exc:
            logger.error("Error presentado construyendo el archivo y guardando en el bucket", exc)
            raise ErrorFile(error_message="Error presentado construyendo el archivo y guardando en el bucket")

    
    def build_data(self, data_column: pd.DataFrame, data_to_insert: pd.DataFrame) -> list:
        try:
            logger.info("Construyendo el contenido del archivo")
            data_string_list = []
            current_index_to_insert = int((data_column[data_column["is_incremental"] =='yes']).loc[0]["default_value"])
            current_index_format = str((data_column[data_column["is_incremental"]=='yes']).loc[0]["pattern"])
            for data_index in range(len(data_to_insert)):
                row_string=""
                row_string_list = []
                row_string_list.append(current_index_format.format(current_index_to_insert))
                for column_info_index in range(1, len(data_column)):
                    if data_column.loc[column_info_index]["value_type"]=="constant":
                        row_string_list.append(data_column.loc[column_info_index]["default_value"])
                    elif pd.isnull(data_to_insert.loc[data_index][data_column.loc[column_info_index]["column_name"]]):
                        row_string_list.append(data_column.loc[column_info_index]["default_value"])
                    else:
                        if data_column.loc[column_info_index]["value_type"]=="date":
                            row_string_list.append(self.format_date(
                                data_to_insert.loc[data_index][data_column.loc[column_info_index]["column_name"]],
                                data_column.loc[column_info_index]["pattern"]
                            ))
                        elif data_column.loc[column_info_index]["value_type"]=="data":
                            row_string_list.append(self.format_field(
                                data_column.loc[column_info_index]["pattern"],
                                data_to_insert.loc[data_index][data_column.loc[column_info_index]["column_name"]]
                            ))
                for row_item in row_string_list:
                    row_string +=row_item
                row_string+="\n"
                data_string_list.append(row_string)
                current_index_to_insert += 1
            return data_string_list
        except Exception as generate_extension_error:
            exception_line = sys.exc_info()[2].tb_lineno
            logger.error(create_log_msg("Error generado consolidando los datos para el archivo: {}".format(generate_extension_error)))


    def sum_values(self, values) -> int:
        try:
            result = 0
            for value in values:
                result+=value
            return result
        except Exception as e:
            logger.error("Se genera un error en la suma de los valores")
            raise ErrorFile(error_message="Se genera un error en la suma de los valores")


    def format_field(self, python_format: str, data: int) -> str:
        try:
            #TODO Poner llaves en db
            python_format_box = python_format
            return python_format_box.format(data)
        except Exception as format_error:
            logger.error("Se genera un error formateando los campos", format_error)
            raise ErrorFile(error_message="Se genera un error formateando los campos")


    def format_date(self, date_to_format: datetime, new_date_format: str) -> str:
        try:
            return date_to_format.strftime(new_date_format)
        except (ValueError, TypeError):
            logger.error("Failed formating date")
            raise ErrorFile(error_message="Error formateando fecha")


    def build_header(self, file_name: str, data_header: pd.DataFrame, data_to_insert: pd.DataFrame, valuation_date: datetime) -> list:
        logger.info("Contruyendo encabezado o registro de control")
        try:
            header_fields_list = []
            for field_index in range(len(data_header)):
                if data_header.loc[field_index]["value_type"] == "constant":
                    header_fields_list.append(data_header.loc[field_index]["default_value"])
                elif data_header.loc[field_index]["value_type"] == "date":
                    header_fields_list.append(self.format_date(valuation_date, data_header.loc[field_index]["pattern"]))
                elif data_header.loc[field_index]["value_type"] == "filename":
                    header_fields_list.append(file_name)
                elif data_header.loc[field_index]["value_type"] == "count":
                    header_fields_list.append(self.format_field(data_header.loc[field_index]["pattern"], len(data_to_insert)))
                elif data_header.loc[field_index]["value_type"] == "sum":
                    header_fields_list.append(self.format_field(data_header.loc[field_index]["pattern"],
                        self.sum_values(data_to_insert[data_header.loc[field_index]["column_reference"]])))
            return header_fields_list
        except Exception as e:
            logger.error("Error generando el encabezado del archivo ", self.entry_file_id)
            raise ErrorFile(error_message="Error generando el encabezado del archivo {}".format(self.entry_file_id))

    def build_file_name(self, file_id: str, valuation_date: datetime) -> str:
        logger.info("Definiendo nombre del archivo")
        try:
            date_formated = self.format_date(valuation_date, "%m%y%d")
            file_name = file_id+date_formated
            file_extension = self.create_extension(file_name)
            complete_file_name = file_name+"."+file_extension
            return complete_file_name
        except Exception as e:
            logger.error(e)
            logger.error("Error generando el nombre del archivo")
            raise ErrorFile(error_message="Error generando el nombre del archivo {}".format(self.entry_file_id))

    def create_extension(self, file_name: str) -> str:
        logger.info("Calculando nueva extension para el archivo")
        try:
            MIN_NUMERIC_EXTENSION = "001"
            directory_content_list = []
            client = boto3.client('s3')
            response = client.list_objects_v2(Bucket=get_enviroment_variable("S3_BUCKET"), Prefix=get_enviroment_variable("S3_PATH"))
            for content in response.get('Contents', []):
                object_file_name = str(content['Key']).replace(get_enviroment_variable("S3_PATH"),"")
                if object_file_name != "":
                    directory_content_list.append(object_file_name)

            for item in directory_content_list:
                item_name_divided = item.split(".")
                if len(item_name_divided) == 2 and item_name_divided[0] == file_name:
                    current_numeric_extension = int(item_name_divided[1])
                    if current_numeric_extension >= int(MIN_NUMERIC_EXTENSION):
                        MIN_NUMERIC_EXTENSION = str(current_numeric_extension + 1).rjust(3, '0')
        except Exception as generate_extension_error:
            exception_line = sys.exc_info()[2].tb_lineno
            logger.error("Error al generar la extension del archivo." + str(exception_line))
        else:
            logger.info("Extension de archivo identificada.")
            return MIN_NUMERIC_EXTENSION

    
    def execute_query(self, database_string_connection: str, query: str) -> pd.DataFrame:
        try:
            sql_engine = create_connection_pool(database_string_connection)
            db_connection_flash = sql_engine.connect()
            logger.info("Iniciando ejecución de consulta a la base de datos...")
            data_consult_df = pd.read_sql(query, con=db_connection_flash)
            db_connection_flash.close()
            return data_consult_df
        except Exception as connection_error:
            exception_line = sys.exc_info()[2].tb_lineno
            logger.error("Se genera un error ejecutando las consultas a la base de datos")
            logger.error(connection_error)
            raise ErrorFile(error_message="Se genera un error ejecutando la consulta a la base de datos")



if __name__ == "__main__":
    FileGenerator().run()