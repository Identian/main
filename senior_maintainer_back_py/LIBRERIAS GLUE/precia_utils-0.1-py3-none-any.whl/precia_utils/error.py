

class BaseError(Exception):
    """Exception personalizada para la capa precia_utils"""



class NoRecords(BaseError):
    def __init__(
        self,
        error_message="La consulta no retorna registros",
    ):
        self.error_message = error_message
        super().__init__(self.error_message)

    def __str__(self):
        return str(self.error_message)


class ErrorFile(BaseError):
    def __init__(
        self,
        error_message="Error generando el archivo",
    ):
        self.error_message = error_message
        super().__init__(self.error_message)

    def __str__(self):
        return str(self.error_message)
